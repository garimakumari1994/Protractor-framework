import { browser, element, by, protractor, $$, $ } from 'protractor';
export class BasePage {
      
    /**
     * This method is used to open URL
     * @param URL 
     */
    // async openApplicationURL(URL: any) {
    //     await browser.manage().window().maximize();
    //     //await browser.manage().timeouts().implicitlyWait(20000);
    //     await browser.get(URL);
    //     await console.log("Inside reg method");
        
   
    // }    
}