"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var BasePage = /** @class */ (function () {
    function BasePage() {
    }
    return BasePage;
}());
exports.BasePage = BasePage;
